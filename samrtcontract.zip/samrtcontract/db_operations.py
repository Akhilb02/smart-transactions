import sqlite3

# Connect to the database (creates the file if it doesn't exist)
conn = sqlite3.connect('invest.db')

# Create a cursor object
cursor = conn.cursor()

# Example SQL commands
# Create a table (if it doesn't exist)
cursor.execute('''
CREATE TABLE IF NOT EXISTS investments (
    id INTEGER PRIMARY KEY,
    user_id TEXT NOT NULL,
    agency TEXT NOT NULL,
    amount REAL NOT NULL,
    duration INTEGER NOT NULL,
    expected_increment REAL NOT NULL
)
''')

# Commit the changes and close the connection
conn.commit()
conn.close()

print("Database and table created successfully!")
