from flask_wtf import FlaskForm
from wtforms import StringField, PasswordField, FloatField, IntegerField, SubmitField
from wtforms.validators import DataRequired, Length

class RegistrationForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired(), Length(min=2, max=20)])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Register')

class LoginForm(FlaskForm):
    username = StringField('Username', validators=[DataRequired()])
    password = PasswordField('Password', validators=[DataRequired()])
    submit = SubmitField('Login')

class InvestmentForm(FlaskForm):
    amount = FloatField('Investment Amount', validators=[DataRequired()])
    agency = StringField('Investment Agency', validators=[DataRequired()])
    duration = IntegerField('Investment Duration (months)', validators=[DataRequired()])
    expected_increment = FloatField('Expected Increment (%)', validators=[DataRequired()])
    submit = SubmitField('Invest')
