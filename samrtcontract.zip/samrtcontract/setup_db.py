import sqlite3

# Connect to SQLite database (it will create the database file if it doesn't exist)
conn = sqlite3.connect('investments.db')

# Create users table
conn.execute('''
CREATE TABLE IF NOT EXISTS users (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    username TEXT NOT NULL,
    password TEXT NOT NULL
);
''')

# Create investments table
conn.execute('''
CREATE TABLE IF NOT EXISTS investments (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    agency TEXT NOT NULL,
    amount REAL NOT NULL,
    duration INTEGER NOT NULL,
    increment REAL NOT NULL
);
''')

# Commit the changes and close the connection
conn.commit()
conn.close()

print("Database setup complete.")
