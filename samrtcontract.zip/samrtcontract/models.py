from flask_sqlalchemy import SQLAlchemy

db = SQLAlchemy()

class Investor(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    username = db.Column(db.String(80), unique=True, nullable=False)
    password = db.Column(db.String(128), nullable=False)
    investment_amount = db.Column(db.Float, nullable=True)
