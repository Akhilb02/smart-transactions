from flask import Flask, render_template, redirect, url_for, request, session, flash

app = Flask(__name__)
app.secret_key = 'supersecretkey'

# Dummy data for default users and admin
users = [{'username': 'user1', 'password': 'password123', 'dashboard_data': 'User1 Dashboard Content'}]
admin = {'username': 'admin', 'password': 'adminpassword', 'dashboard_data': 'Admin Dashboard Content'}

# Index page
@app.route('/')
def index():
    return render_template('index.html')

# User registration page
@app.route('/register', methods=['GET', 'POST'])
def register():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        users.append({'username': username, 'password': password, 'dashboard_data': f'{username} Dashboard Content'})
        flash('Registration successful! You can now log in.')
        return redirect(url_for('login'))
    return render_template('register.html')

# User login page
@app.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        # Check if user exists
        for user in users:
            if user['username'] == username and user['password'] == password:
                session['username'] = username
                session['dashboard'] = user['dashboard_data']
                return redirect(url_for('user_dashboard'))
        flash('Invalid username or password.')
    return render_template('login.html')

# User dashboard
@app.route('/user_dashboard')
def user_dashboard():
    if 'username' in session:
        return render_template('user_dashboard.html', username=session['username'], dashboard_data=session['dashboard'])
    else:
        return redirect(url_for('login'))

# Admin login page
@app.route('/admin_login', methods=['GET', 'POST'])
def admin_login():
    if request.method == 'POST':
        username = request.form['username']
        password = request.form['password']
        if username == admin['username'] and password == admin['password']:
            session['admin'] = username
            return redirect(url_for('admin_dashboard'))
        else:
            flash('Invalid admin credentials.')
    return render_template('admin_login.html')

# Admin dashboard
@app.route('/admin_dashboard')
def admin_dashboard():
    if 'admin' in session:
        return render_template('admin_dashboard.html', dashboard_data=admin['dashboard_data'], users=users)
    else:
        return redirect(url_for('admin_login'))

# Investment page
@app.route('/invest', methods=['GET', 'POST'])
def invest():
    if request.method == 'POST':
        # Investment logic goes here
        agency = request.form['agency']
        amount = request.form['amount']
        duration = request.form['duration']
        flash(f'Investment of {amount} in {agency} for {duration} has been recorded!')
        return redirect(url_for('user_dashboard'))
    return render_template('invest.html')

# Logout route (for both user and admin)
@app.route('/logout')
def logout():
    session.clear()
    return redirect(url_for('index'))

if __name__ == '__main__':
    app.run(debug=True)
